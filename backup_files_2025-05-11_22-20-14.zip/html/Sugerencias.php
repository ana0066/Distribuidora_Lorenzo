<!DOCTYPE html>
<html>
<head>
	<title>Sugerencias</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/sugerencias.css">
</head>
<body>
    <form method="post">
    	<h1>¡Dejanos tus sugerencias!</h1>
    	<input type="text" name="name" placeholder="Nombre completo">
    	<input type="name" name="email" placeholder="Email">
    	<input type="submit" name="register">
    </form>
        <?php 
        include("registrar.php");
        ?>
</body>
</html>